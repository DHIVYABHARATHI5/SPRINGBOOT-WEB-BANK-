package com.botree;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class BankDao {
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public BankDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Transactional
    public void transferMoney(int fromAccountNumber, int toAccountNumber, double amount) throws DataAccessException, InsufficientBalanceException {
        try {
            // Validate if both accounts exist and the source account has sufficient balance
            double sourceBalance = jdbcTemplate.queryForObject("SELECT amount FROM Account WHERE acnumber = ?", Double.class, fromAccountNumber);
            double targetBalance = jdbcTemplate.queryForObject("SELECT amount FROM Account WHERE acnumber = ?", Double.class, toAccountNumber);

            if (sourceBalance < amount) {
                throw new InsufficientBalanceException("Insufficient balance in the source account.");
            }

            // Update the source and target account balances
            double newSourceBalance = sourceBalance - amount;
            double newTargetBalance = targetBalance + amount;

            jdbcTemplate.update("UPDATE Account SET amount = ? WHERE acnumber = ?", newSourceBalance, fromAccountNumber);
            jdbcTemplate.update("UPDATE Account SET amount = ? WHERE acnumber = ?", newTargetBalance, toAccountNumber);
        } catch (DataAccessException e) {
            e.printStackTrace();
            throw e;
        }
    }
    
    
    @Transactional
    public void depositMoney(int AccountNumber, String Username, double amount) throws DataAccessException, InsufficientBalanceException {
        try {
            double currentBalance = jdbcTemplate.queryForObject("SELECT amount FROM Account WHERE acnumber = ?", Double.class, AccountNumber);

            double newBalance = currentBalance + amount;

            jdbcTemplate.update("UPDATE Account SET amount = ? WHERE acnumber = ?", newBalance, AccountNumber);
        } catch (DataAccessException e) {
            e.printStackTrace();
            throw e;
        }
    }

    
    @Transactional
    public void withdrawMoney(int AccountNumber, String Username, double amount) throws DataAccessException, InsufficientBalanceException {
        try {
            double currentBalance = jdbcTemplate.queryForObject("SELECT amount FROM Account WHERE acnumber = ?", Double.class, AccountNumber);

            if (currentBalance < amount) {
                throw new InsufficientBalanceException("Insufficient balance in the account.");
            }

            double newBalance = currentBalance - amount;

            jdbcTemplate.update("UPDATE Account SET amount = ? WHERE acnumber = ?", newBalance, AccountNumber);
        } catch (DataAccessException e) {
            e.printStackTrace();
            throw e;
        }
    }

    
    
    
    public boolean createAccount(Banks banks) throws DuplicateIdException {
        String sql = "INSERT INTO createaccount (id, Username, Gender, Address1, Address2, Land_Phone_no, Mobile, Email) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            jdbcTemplate.update(
                sql,
                banks.getId(),
                banks.getUsername(),
                banks.getGender(),
                banks.getAddress1(),
                banks.getAddress2(),
                banks.getLand_Phone_no(),
                banks.getMobile(),
                banks.getEmail()
            );
            return true;
        } catch (Exception e) {
        	throw new DuplicateIdException(banks.getId()+"already exists");
          //  e.printStackTrace();
          //  return false;
        }
    }


    public double checkBalance(int accountNumber) {
        try {
            String sql = "SELECT amount FROM Account WHERE acnumber = ?";
            Double balance = jdbcTemplate.queryForObject(sql, Double.class, accountNumber);
            return (balance != null) ? balance : 0.0; 
        } catch (Exception e) {
            e.printStackTrace();
            return 0.0; 
        }
    }
    
    @Transactional
    public void closeAccount(int accountNumber) {
        jdbcTemplate.update("DELETE FROM Account WHERE acnumber = ?", accountNumber);
    }

	

}




/*package com.botree;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.util.HashMap;
import java.util.Map;

@Repository
public class BankDao {

    @Autowired
    private NamedParameterJdbcTemplate jdbcTemplate;

    @Transactional
    public void transferMoney(int sourceAccountNumber, int targetAccountNumber, double amount) {
        
    	try {
    		deductMoney(sourceAccountNumber, amount);

           
            addMoney(targetAccountNumber, amount);

		} catch (Exception e) {
			e.printStackTrace();
		}
        
        
    }

    private void deductMoney(int accountNumber, double amount) {
        String sql = "UPDATE createaccount SET amount = amount - :amount WHERE acnumber = :accountNumber";
        Map<String, Object> params = new HashMap<>();
        params.put("amount", amount);
        params.put("accountNumber", accountNumber);
        jdbcTemplate.update(sql, params);
    }

    private void addMoney(int accountNumber, double amount) {
        String sql = "UPDATE createaccount SET amount = amount + :amount WHERE acnumber = :accountNumber";
        Map<String, Object> params = new HashMap<>();
        params.put("amount", amount);
        params.put("accountNumber", accountNumber);
        jdbcTemplate.update(sql, params);
    }
}*/
