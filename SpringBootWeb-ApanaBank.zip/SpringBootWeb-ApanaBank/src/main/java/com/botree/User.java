package com.botree;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class User {

	
	@NotBlank(message="Id is mandatory")
	@Size(min=3,max=20,message="min 3 letter and max 20 letter")

	private String id;
	
	@NotBlank(message="Password is mandatory")
	@Pattern(regexp = ".*\\*.*", message = "Password must contain the '*' symbol")
	@Size(min=8,max=10,message="min 8 letter and max 10 letter")

	private String password;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
	
	
}



