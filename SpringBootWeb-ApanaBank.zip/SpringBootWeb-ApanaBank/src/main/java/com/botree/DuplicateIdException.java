package com.botree;

public class DuplicateIdException extends Exception {

	public DuplicateIdException(String msg) {
		super(msg);
	}
}
