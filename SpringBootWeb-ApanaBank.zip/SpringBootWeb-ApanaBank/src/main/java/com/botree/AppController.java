package com.botree;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller

public class AppController {
	
	@Autowired
	UserBo userBo;
	

	@Autowired
	BankDao bankdao;
	
	@Autowired
	NamedParameterJdbcTemplate template;
	
	



	@GetMapping("login")
	public String loginPage(@ModelAttribute User user,Model model) {

		// model.addAttribute("user", new User());
	//	user.setName("abc");
		
		return "login";
	}
	
	@PostMapping("validate")
	public ModelAndView validateUser(@ModelAttribute @Valid User user,BindingResult result) {
		
		
		var mv=new ModelAndView("login");
		if(result.hasErrors()) {
			//System.out.println(result.getFieldErrors());
			return mv;
		}
		if(userBo.validateUser(user)) {
			mv.setViewName("home");
			mv.addObject("Welcome",user.getId());
		}else {
			mv.setViewName("login");
			mv.addObject("error","Invalid username or password");
		}
		return mv;
	    
	 
	}
	
	
	@GetMapping("createaccount")
    public String createaccount(@ModelAttribute Banks banks, Model model) {
       
		
		model.addAttribute("page","createaccount");
        return "home";
    }
	
	
	@PostMapping("create")
public ModelAndView createaccount(@ModelAttribute @Valid Banks banks,BindingResult result) throws DuplicateIdException {
		
		var mv=new ModelAndView("home");
		if(result.hasErrors()) {
			mv.addObject("page", "createaccount");
			return mv;
		}
		bankdao.createAccount(banks);
	    mv.setViewName("home");
	    mv.addObject("success","Account created sucessfully");
	    mv.addObject("emp1","duplicate value found");
	    mv.addObject("page","createaccount");
	    banks=new Banks();
		return mv;
	}
	
	
	@GetMapping("balancecheck")
    public String checkbalance(@ModelAttribute Bank bank, Model model) {
       
		
		model.addAttribute("page","balancecheck");
        return "home";
    }
	
	@PostMapping("balance")
	public ModelAndView checkBalance(@ModelAttribute Bank bank) {
	    ModelAndView mv = new ModelAndView("home");

	    int accountNumber = bank.getAcnumber();

	    double balance = bankdao.checkBalance(accountNumber);

	    if (balance >= 0) {
	        mv.addObject("successMessage", "Account Balance: " + balance);
	    } else {
	        mv.addObject("errorMessage", "Failed to check account balance. Please check the account number.");
	    }

	    mv.setViewName("home");
	    return mv;
	}

	
	
	@GetMapping("transferform")
    public String transferForm(@ModelAttribute Bank bank, Model model) {
       
		
		model.addAttribute("page","transferform");
        return "home";
    }

    @PostMapping("transfer")
    public ModelAndView transferMoney(@ModelAttribute @Valid Bank bank, BindingResult result) {
        var mv = new ModelAndView("home");
        if (result.hasErrors()) {
            return mv;
        }

        try {
            
            bankdao.transferMoney(bank.getAcnumber(), bank.getTarget_acnumber(), bank.getAmount());
            mv.addObject("successMessage", "Money transferred successfully.");
            mv.setViewName("home");
        } catch (Exception e) {
            mv.addObject("errorMessage", "Money transfer failed. Please check your inputs.");
            mv.setViewName("home");
        }

        return mv;
    }
	
	
	@GetMapping("depositform")
    public String depositForm(@ModelAttribute Bank bank, Model model) {
       
		
		model.addAttribute("page","depositform");
        return "home";
    }

    @PostMapping("deposit")
    public ModelAndView depositMoney(@ModelAttribute @Valid Bank bank, BindingResult result) {
        var mv = new ModelAndView("home");
        if (result.hasErrors()) {
            return mv;
        }

        try {
            
            bankdao.depositMoney(bank.getAcnumber(), bank.getUsername(), bank.getAmount());
            mv.addObject("successMessage", "Money Deposit successfully.");
            mv.setViewName("home");
        } catch (Exception e) {
            mv.addObject("errorMessage", "Money deposit failed. Please check your inputs.");
            mv.setViewName("home");
        }

        return mv;
    }
	
    @GetMapping("withdrawform")
    public String withdrawForm(@ModelAttribute Bank bank, Model model) {
       
		
		model.addAttribute("page","withdrawform");
        return "home";
    }

    @PostMapping("withdraw")
    public ModelAndView withdrawMoney(@ModelAttribute @Valid Bank bank, BindingResult result) {
        var mv = new ModelAndView("home");
        if (result.hasErrors()) {
            return mv;
        }

        try {
            
            bankdao.withdrawMoney(bank.getAcnumber(), bank.getUsername(), bank.getAmount());
            mv.addObject("successMessage", "Money Withdraw successfully.");
            mv.setViewName("home");
        } catch (Exception e) {
            mv.addObject("errorMessage", "Money Withdraw failed. Please check your inputs.");
            mv.setViewName("home");
        }
        return mv;
    }
    
    
    
    @GetMapping("closeaccount")
    public String closeaccount(@ModelAttribute Bank bank,Model model) {
    	model.addAttribute("page","closeaccount");
        return "home";
    }

    @PostMapping("close")
    public ModelAndView closeAccount(@ModelAttribute @Valid Bank bank, BindingResult result) {
        ModelAndView mv = new ModelAndView("home");

        if (result.hasErrors()) {
            return mv;
        }

        int accountNumber = bank.getAcnumber();

        try {
            bankdao.closeAccount(accountNumber);
            mv.addObject("successMessage", "Account closed successfully.");
        } catch (Exception e) {
            mv.addObject("errorMessage", "Failed to close the account. Please check the account number.");
        }

        return mv;
    }

    
    
    @GetMapping("logout")
    public String logout(HttpServletRequest request, SessionStatus sessionStatus) {
        sessionStatus.setComplete();

        return "redirect:/login"; 
    }


    
	
}
