package com.botree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebApanaBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebApanaBankApplication.class, args);
	}

}
