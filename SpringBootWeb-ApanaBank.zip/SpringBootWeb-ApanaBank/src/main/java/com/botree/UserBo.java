package com.botree;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserBo {

	@Autowired
	UserDao userDao;
	
	public boolean validateUser(User user) {
		
		var u=userDao.getUser(user);
		
		if(u!=null && u.getId().equals(user.getId())&& u.getPassword().equals(user.getPassword())) {
			return true;
		}
		return false;
	}
}
