package com.botree;

public class Bank {

	private String id;
	private int acnumber;
	private int amount;
	private int target_acnumber;
	private String Username;
	private String password;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getAcnumber() {
		return acnumber;
	}
	public void setAcnumber(int acnumber) {
		this.acnumber = acnumber;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getTarget_acnumber() {
		return target_acnumber;
	}
	public void setTarget_acnumber(int target_acnumber) {
		this.target_acnumber = target_acnumber;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
	
}
