package com.botree;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UserDao {

	
	@Autowired
	NamedParameterJdbcTemplate template;
	
	public User getUser(User user) {
		String sql = "select * from login where id=:id";
		try {
			var us = template.query(sql, new MapSqlParameterSource("id", user.getId()), 
					(rs) -> {
				if (rs.next()) {
					User use = new User();
					use.setId(rs.getString("id"));
					use.setPassword(rs.getString("password"));
					return use;

				}
				return null;

			});
return us;
		} catch (Exception e) {
      e.printStackTrace();
      return user;
		}

	
	}
	
	
	
	
	
}
