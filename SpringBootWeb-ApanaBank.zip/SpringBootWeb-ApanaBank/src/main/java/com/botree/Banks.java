package com.botree;

public class Banks {

	
	private String id;
	private  String Username;
	private String Gender;
	private String Address1;
	private String Address2;
	private String Land_Phone_no;
	private String Mobile;
	private String Email;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getAddress1() {
		return Address1;
	}
	public void setAddress1(String address1) {
		Address1 = address1;
	}
	public String getAddress2() {
		return Address2;
	}
	public void setAddress2(String address2) {
		Address2 = address2;
	}
	public String getLand_Phone_no() {
		return Land_Phone_no;
	}
	public void setLand_Phone_no(String land_Phone_no) {
		Land_Phone_no = land_Phone_no;
	}
	public String getMobile() {
		return Mobile;
	}
	public void setMobile(String mobile) {
		Mobile = mobile;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	
	
	
}
