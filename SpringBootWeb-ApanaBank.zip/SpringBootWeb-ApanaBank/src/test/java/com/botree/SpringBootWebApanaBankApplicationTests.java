package com.botree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebApanaBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
